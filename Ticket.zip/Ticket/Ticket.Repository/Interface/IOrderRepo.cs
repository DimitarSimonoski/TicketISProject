﻿using Ticket_Domain;
using Ticket_Domain.Domain_Models;

namespace Ticket.Ticket_Repository.Interface
{
    public interface IOrderRepo
    {
        public List<Order> getAllOrders();
        public Order getOrderDetails(BaseEntity model);

    }
}