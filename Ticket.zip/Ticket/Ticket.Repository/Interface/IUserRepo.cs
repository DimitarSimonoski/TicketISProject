﻿using Ticket_Domain.Identify;

namespace Ticket.Ticket_Repository.Interface
{
    public interface IUserRepo
    {
        IEnumerable<EShopApplicationUser> GetAll();
        EShopApplicationUser Get(string id);
        void Insert(EShopApplicationUser entity);
        void Update(EShopApplicationUser entity);
        void Delete(EShopApplicationUser entity);
    }
}