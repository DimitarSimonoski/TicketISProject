﻿using Ticket.Data;
using Ticket.Ticket_Repository.Interface;
using Microsoft.EntityFrameworkCore;
using Ticket_Domain.Domain_Models;
using Ticket_Domain;

namespace Ticket.Ticket_Repository.Implementations
{
    public class OrderRepo : IOrderRepo
    {
        private readonly ApplicationDbContext context;
        private DbSet<Order> entities;
        string errorMessage = string.Empty;

        public OrderRepo(ApplicationDbContext context)
        {
            this.context = context;
            entities = context.Set<Order>();
        }
        public List<Order> getAllOrders()
        {
            return entities
                .Include(z => z.User)
                .Include(z => z.TicketInOrders)
                .Include("TicketsInOrder.Ticket")
                .ToListAsync().Result;
        }

        public Order getOrderDetails(BaseEntity model)
        {
            return entities
               .Include(z => z.User)
               .Include(z => z.TicketInOrders)
               .Include("TicketsInOrder.Ticket")
               .SingleOrDefaultAsync(z => z.Id == model.Id).Result;
        }
    }
}
