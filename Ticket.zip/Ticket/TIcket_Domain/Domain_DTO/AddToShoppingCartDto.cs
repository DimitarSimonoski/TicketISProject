﻿using Ticket_Domain.Domain_Models;

namespace Ticket_Domain.Domain_DTO
{
    public class AddToShoppingCartDTO
    {
        public The_Ticket SelectedTicket { get; set; }
        public Guid SelectedTicketId { get; set; }
        public int Quantity { get; set; }
    }
}