﻿using Ticket_Domain.Relations;

namespace Ticket_Domain.Domain_DTO
{
    public class ShoppingCartDTO
    {
        public List<TicketsInShoppingCart> Tickets { get; set; }

        public double TotalPrice { get; set; }
    }
}