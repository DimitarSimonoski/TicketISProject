﻿using Ticket_Domain.Identify;
using Ticket_Domain.Relations;

namespace Ticket_Domain.Domain_Models
{
    public class ShoppingCart : BaseEntity

    {
        public string OwnerId { get; set; }
        public virtual EShopApplicationUser Owner { get; set; }

        public virtual ICollection<TicketsInShoppingCart> TicketInShoppingCarts { get; set; }

    }
}