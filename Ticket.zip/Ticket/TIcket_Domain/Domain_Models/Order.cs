﻿using Ticket_Domain.Identify;
using Ticket_Domain.Relations;

namespace Ticket_Domain.Domain_Models
{
    public class Order : BaseEntity
    {
        public string UserId { get; set; }
        public EShopApplicationUser User { get; set; }

        public virtual ICollection<TicketsInOrder> TicketInOrders { get; set; }
    }
}