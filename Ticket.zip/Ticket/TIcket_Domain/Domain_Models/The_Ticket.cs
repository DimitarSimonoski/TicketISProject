﻿using System.ComponentModel.DataAnnotations;
using Ticket_Domain.Relations;

namespace Ticket_Domain.Domain_Models
{
    public class The_Ticket : BaseEntity
    {
        [Required]
        public string The_TicketName { get; set; }
        [Required]
        public string The_TicketImage { get; set; }
        [Required]
        public string The_TicketDescription { get; set; }
        [Required]
        public double The_TicketPrice { get; set; }
        [Required]
        public string Genre { get; set; }
        [Required]
        public DateTime date { get; set; }

        public virtual ICollection<TicketsInShoppingCart>? TicketInShoppingCarts { get; set; }
        public virtual ICollection<TicketsInOrder>? TicketInOrders { get; set; }
    }
}