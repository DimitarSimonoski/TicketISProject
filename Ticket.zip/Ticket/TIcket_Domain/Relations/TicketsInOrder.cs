﻿using Ticket_Domain;
using Ticket_Domain.Domain_Models;

namespace Ticket_Domain.Relations
{
    public class TicketsInOrder : BaseEntity
    {

        public int Quantity { get; set; }
        public Guid OrderId { get; set; }
        public Order Order { get; set; }

        public Guid TicketId { get; set; }
        public The_Ticket Ticket { get; set; }
    }
}