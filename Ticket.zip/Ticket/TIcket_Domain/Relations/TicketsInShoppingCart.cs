﻿using Ticket_Domain;
using Ticket_Domain.Domain_Models;

namespace Ticket_Domain.Relations
{
    public class TicketsInShoppingCart : BaseEntity
    {
        public Guid TicketId { get; set; }
        public virtual The_Ticket CurrentTicket { get; set; }

        public Guid ShoppingCartId { get; set; }
        public virtual ShoppingCart UserCart { get; set; }

        public int Quantity { get; set; }
    }
}