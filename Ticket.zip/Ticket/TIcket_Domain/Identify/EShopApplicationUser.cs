﻿using Microsoft.AspNetCore.Identity;
using Ticket_Domain.Domain_Models;

namespace Ticket_Domain.Identify
{
    public class EShopApplicationUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public virtual ShoppingCart UserCart { get; set; }
    }
}