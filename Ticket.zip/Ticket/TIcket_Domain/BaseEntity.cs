﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ticket_Domain
{
    public class BaseEntity
    {
        public Guid Id { get; set; }


    }
}