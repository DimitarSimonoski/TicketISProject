﻿using Ticket_Domain.Domain_DTO;
using Ticket_Domain.Domain_Models;

namespace Ticket.Ticket_Service.Interface
{
    public interface ITicketServices
    {
        List<The_Ticket> GetAllTickets();
        The_Ticket GetDetailsForTicket(Guid? id);
        void CreateNewTicket(The_Ticket p);
        void UpdeteExistingTicket(The_Ticket p);
        AddToShoppingCartDTO GetShoppingCartInfo(Guid? id);
        void DeleteTicket(Guid id);
        bool AddToShoppingCart(AddToShoppingCartDTO item, string userID);
    }
}
