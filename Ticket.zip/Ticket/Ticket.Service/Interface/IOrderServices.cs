﻿using Ticket_Domain;
using Ticket_Domain.Domain_Models;

namespace Ticket.Service.Interface
{
    public interface IOrderServices
    {
        public List<Order> getAllOrders();
        public Order getOrderDetails(BaseEntity model);
    }
}