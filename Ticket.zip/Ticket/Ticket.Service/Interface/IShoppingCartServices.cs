﻿using Ticket_Domain.Domain_DTO;

namespace Ticket.Service.Interface
{
    public interface IShoppingCartServices
    {
        ShoppingCartDTO getShoppingCartInfo(string userId);
        bool deleteTicketFromSoppingCart(string userId, Guid TicketId);
        bool order(string userId);
    }
}