﻿namespace Ticket.Ticke_Service.Implementation
{
    internal interface IRepo<T>
    {
    }
}