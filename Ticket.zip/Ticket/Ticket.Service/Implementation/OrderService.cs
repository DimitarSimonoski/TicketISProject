﻿using Ticket.Service.Interface;
using Ticket_Domain;
using Ticket_Domain.Domain_Models;

namespace LabIS.Service.Implementation
{
    public class OrderService : IOrderServices
    {
        private readonly IOrderRepo _orderRepository;

        public OrderService(IOrderRepo orderRepository)
        {
            _orderRepository = orderRepository;
        }
        public List<Order> getAllOrders()
        {
            return this._orderRepository.getAllOrders();
        }

        public Order getOrderDetails(BaseEntity model)
        {
            return this._orderRepository.getOrderDetails(model);
        }
    }
}