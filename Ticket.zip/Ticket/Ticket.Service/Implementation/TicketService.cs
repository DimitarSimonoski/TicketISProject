﻿using Ticket.Ticke_Service.Implementation;
using Ticket.Ticket_Service.Interface;
using Ticket_Domain.Domain_DTO;
using Ticket_Domain.Domain_Models;
using Ticket_Domain.Relations;

namespace Ticket.Ticket_Service.Implementation
{
    public class TicketService : ITicketServices
    {
        private readonly IRepo<The_Ticket> _ticketRepository;
        private readonly IRepo<TicketsInShoppingCart> _ticketInShoppingCartRepository;
        private readonly IUserRepo _userRepository;

        public TicketService(IRepo<The_Ticket> ticketRepository, IRepo<TicketsInShoppingCart> ticketInShoppingCartRepository, IUserRepo userRepository)
        {
            _ticketRepository = ticketRepository;
            _userRepository = userRepository;
            _ticketInShoppingCartRepository = ticketInShoppingCartRepository;
        }


        public bool AddToShoppingCart(AddToShoppingCartDTO item, string userID)
        {
            var user = this._userRepository.Get(userID);

            var userShoppingCard = user.UserCart;

            if (item.SelectedTicketId != null && userShoppingCard != null)
            {
                var product = this.GetDetailsForTicket(item.SelectedTicketId);

                if (product != null)
                {
                    TicketsInShoppingCart itemToAdd = new TicketsInShoppingCart
                    {
                        Id = Guid.NewGuid(),
                        CurrentTicket = product,
                        TicketId = product.Id,
                        UserCart = userShoppingCard,
                        ShoppingCartId = userShoppingCard.Id,
                        Quantity = item.Quantity
                    };


                    var existing = userShoppingCard.TicketInShoppingCarts.Where(z => z.ShoppingCartId == userShoppingCard.Id && z.TicketId == itemToAdd.TicketId).FirstOrDefault();

                    if (existing != null)
                    {
                        existing.Quantity += itemToAdd.Quantity;
                        this._ticketInShoppingCartRepository.Update(existing);

                    }
                    else
                    {
                        this._ticketInShoppingCartRepository.Insert(itemToAdd);
                    }

                    return true;
                }
                return false;
            }
            return false;
        }

        public void CreateNewTicket(The_Ticket t)
        {
            this._ticketRepository.Insert(t);
        }

        public void DeleteTicket(Guid id)
        {
            var ticket = this.GetDetailsForTicket(id);
            this._ticketRepository.Delete(ticket);
        }

        public List<The_Ticket> GetAllTickets()
        {
            return this._ticketRepository.GetAll().ToList();
        }

        public The_Ticket GetDetailsForTicket(Guid? id)
        {
            return this._ticketRepository.Get(id);
        }

        public AddToShoppingCartDTO GetShoppingCartInfo(Guid? id)
        {
            var ticket = this.GetDetailsForTicket(id);
            AddToShoppingCartDTO model = new AddToShoppingCartDTO
            {
                SelectedTicket = ticket,
                SelectedTicketId = ticket.Id,
                Quantity = 1
            };

            return model;
        }

        public void UpdeteExistingTicket(The_Ticket t)
        {
            this._ticketRepository.Update(t);
        }
    }
}