﻿using Octopus.Client.Repositories;
using System.Text;
using Ticket.Service.Interface;
using Ticket_Domain.Domain_DTO;
using Ticket_Domain.Domain_Models;
using Ticket_Domain.Relations;
using Ticket_Repository.Interface;

namespace Ticket.Ticke_Service.Implementation
{
    public class CartService : IShoppingCartServices
    {
        private readonly IRepo<ShoppingCart> _shoppingCartRepository;
        private readonly IRepo<Order> _orderRepository;
        private readonly IRepo<TicketsInOrder> _ticketInOrderRepository;
        private readonly IUserRepo _userRepository;

        public CartService(IRepo<ShoppingCart> shoppingCartRepository, IUserRepository userRepository, IRepo<Order> orderRepository, IRepo<TicketsInOrder> ticketInOrderRepository)
        {
            _shoppingCartRepository = shoppingCartRepository;
            _userRepository = userRepository;
            _orderRepository = orderRepository;
            _ticketInOrderRepository = ticketInOrderRepository;
        }


        public bool deleteTicketFromSoppingCart(string userId, Guid ticketId)
        {
            if (!string.IsNullOrEmpty(userId) && ticketId != null)
            {
                var loggedInUser = this._userRepository.Get(userId);

                var userShoppingCart = loggedInUser.UserCart;

                var itemToDelete = userShoppingCart.TicketInShoppingCarts.Where(z => z.TicketId.Equals(ticketId)).FirstOrDefault();

                userShoppingCart.TicketInShoppingCarts.Remove(itemToDelete);

                this._shoppingCartRepository.Update(userShoppingCart);

                return true;
            }
            return false;
        }

        public ShoppingCartDTO getShoppingCartInfo(string userId)
        {
            if (!string.IsNullOrEmpty(userId))
            {
                var loggedInUser = this._userRepository.Get(userId);

                var userCard = loggedInUser.UserCart;

                var allTickets = userCard.TicketInShoppingCarts.ToList();

                var allTicketPrices = allTickets.Select(z => new
                {
                    TicketPrice = z.CurrentTicket.TicketPrice,
                    Quantity = z.Quantity
                }).ToList();

                double totalPrice = 0.0;

                foreach (var item in allTicketPrices)
                {
                    totalPrice += item.Quantity * item.TicketPrice;
                }

                var reuslt = new ShoppingCartDTO
                {
                    Tickets = allTickets,
                    TotalPrice = totalPrice
                };

                return reuslt;
            }
            return new ShoppingCartDTO();
        }

        public bool order(string userId)
        {
            if (!string.IsNullOrEmpty(userId))
            {
                var loggedInUser = this._userRepository.Get(userId);
                Order order = new Order
                {
                    Id = Guid.NewGuid(),
                    User = loggedInUser,
                    UserId = userId
                };

                this._orderRepository.Insert(order);

                List<TicketsInOrder> ticketInOrders = new List<TicketsInOrder>();

                var result = userCard.TicketInShoppingCarts.Select(z => new TicketsInOrder
                {
                    Id = Guid.NewGuid(),
                    TicketId = z.CurrentTicket.Id,
                    Ticket = z.CurrentTicket,
                    OrderId = order.Id,
                    Order = order,
                    Quantity = z.Quantity
                }).ToList();
                StringBuilder sb = new StringBuilder();

                var totalPrice = 0.0;

                sb.AppendLine("Your order is completed. The order conatins: ");

                for (int i = 1; i <= result.Count(); i++)
                {
                    var currentItem = result[i - 1];
                    totalPrice += currentItem.Quantity * currentItem.Ticket.TicketPrice;
                    sb.AppendLine(i.ToString() + ". " + currentItem.Ticket.TicketName + " with quantity of: " + currentItem.Quantity + " and price of: $" + currentItem.Ticket.TicketPrice);
                }

                sb.AppendLine("Total price for your order: " + totalPrice.ToString());



                ticketInOrders.AddRange(result);

                foreach (var item in ticketInOrders)
                {
                    this._ticketInOrderRepository.Insert(item);
                }

                loggedInUser.UserCart.TicketInShoppingCarts.Clear();

                this._userRepository.Update(loggedInUser);


                return true;
            }

            return false;
        }
    }
}